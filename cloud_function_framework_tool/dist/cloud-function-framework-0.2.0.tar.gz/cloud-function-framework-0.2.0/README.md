# Cloud Function Framework
A CLI tool to bootstrap Google Cloud Functions projects effortlessly.